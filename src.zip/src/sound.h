#include <stdint.h>
void playNote(uint32_t Freq);
void initSound(void);